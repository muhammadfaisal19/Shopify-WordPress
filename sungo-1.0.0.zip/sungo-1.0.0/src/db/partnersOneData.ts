export const partnetsOneData = [
    {
        id: 1,
        img: '/img/brand.png'
    },
    {
        id: 2,
        img: '/img/brand.png'
    },
    {
        id: 3,
        img: '/img/brand.png'
    },
    {
        id: 4,
        img: '/img/brand.png'
    },
    {
        id: 5,
        img: '/img/brand.png'
    },
    {
        id: 6,
        img: '/img/brand.png'
    },
    {
        id: 7,
        img: '/img/brand.png'
    },
]