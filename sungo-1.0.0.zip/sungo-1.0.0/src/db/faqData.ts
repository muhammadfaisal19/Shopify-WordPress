export const faqData = [
  {
    id: 'faq1',
    question: 'How to use Solaren?',
    answer: 'There are many variations of passages Lorem Ipsum but the majority have suffered alteration in some form, by injected humor.',
    delay: '.3',
    isOpen: false
  },
  {
    id: 'faq2',
    question: 'What services does you offer?',
    answer: 'There are many variations of passages Lorem Ipsum but the majority have suffered alteration in some form, by injected humor.',
    delay: '.5',
    isOpen: true
  },
  {
    id: 'faq3',
    question: 'How to soft launch your business?',
    answer: 'There are many variations of passages Lorem Ipsum but the majority have suffered alteration in some form, by injected humor.',
    delay: '.7',
    isOpen: false
  }
];

export const faqDataTwo = [
  {
    id: 'faq1',
    question: 'How long should a business plan be?',
    answer: 'There are many variations of passages Lorem Ipsum but the majority have suffered alteration in some form, by injected humor.',
    delay: '.3',
    expanded: false,
  },
  {
    id: 'faq2',
    question: 'What is included in your services?',
    answer: 'There are many variations of passages Lorem Ipsum but the majority have suffered alteration in some form, by injected humor.',
    delay: '.5',
    expanded: true,
  },
  {
    id: 'faq3',
    question: 'What type of company is measured?',
    answer: 'There are many variations of passages Lorem Ipsum but the majority have suffered alteration in some form, by injected humor.',
    delay: '.7',
    expanded: false,
  },
];