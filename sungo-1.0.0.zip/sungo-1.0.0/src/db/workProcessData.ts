export const workProcessData = [
    {
      id: 1,
      icon: '/img/process/01.svg',
      title: 'Project Planning',
      description: 'In a free hour, when our power of choice is untrammeled and',
    },
    {
      id: 2,
      icon: '/img/process/02.svg',
      title: 'Research & Analysis',
      description: 'In a free hour, when our power of choice is untrammeled and',
      style: 'style-2',
    },
    {
      id: 3,
      icon: '/img/process/03.svg',
      title: 'Solar Installation',
      description: 'In a free hour, when our power of choice is untrammeled and',
    },
    {
      id: 4,
      icon: '/img/process/04.svg',
      title: 'LuxSolar Dynamics',
      description: 'In a free hour, when our power of choice is untrammeled and',
      style: 'style-2',
    },
  ];
  