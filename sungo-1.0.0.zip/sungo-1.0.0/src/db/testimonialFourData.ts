export const testimonialFourData = [
    {
        id: 1,
        quote: 'when an unknown printer took away galley of type aawer awtnd there are scrambled it to make a type many but also the leap into',
        image: '/img/testimonial/05.jpg',
        name: 'Shikhon Haque',
        role: 'Web Designer',
        stars: 5
    },
    {
        id: 2,
        quote: 'when an unknown printer took away galley of type aawer awtnd there are scrambled it to make a type many but also the leap into',
        image: '/img/testimonial/06.jpg',
        name: 'Esther Howard',
        role: 'President of Sales',
        stars: 5
    },
    {
        id: 3,
        quote: 'when an unknown printer took away galley of type aawer awtnd there are scrambled it to make a type many but also the leap into',
        image: '/img/testimonial/07.jpg',
        name: 'Brooklyn Simmons',
        role: 'Nursing',
        stars: 5
    },
    {
        id: 4,
        quote: 'when an unknown printer took away galley of type aawer awtnd there are scrambled it to make a type many but also the leap into',
        image: '/img/testimonial/06.jpg',
        name: 'Esther Howard',
        role: 'President of Sales',
        stars: 5
    },
];