export const testimonialsOneData = [
    {
        id:1,
        image: "/img/testimonial/01.jpg",
        stars: 5,
        title: "Testimonials",
        heading: "What’s Clients Say",
        content: "Nullam dignissim, ante scelerisque the is euismod fermentum odio sem semper the is erat, a feugiat leo urna eget eros. Duis Aenean a imperdiet risus. Aliquam pellentesque nisi dui eget dapibus enim ornare eu. Morbi nunc metus, maximus eu mauris.",
        author: "Kathryn Murphy",
        position: "Web Designer"
    },
    {
        id:2,
        image: "/img/testimonial/01.jpg",
        stars: 5,
        title: "Testimonials",
        heading: "What’s Clients Say",
        content: "Nullam dignissim, ante scelerisque the is euismod fermentum odio sem semper the is erat, a feugiat leo urna eget eros. Duis Aenean a imperdiet risus. Aliquam pellentesque nisi dui eget dapibus enim ornare eu. Morbi nunc metus, maximus eu mauris.",
        author: "Kathryn Murphy",
        position: "Web Designer"
    },
    {
        id:3,
        image: "/img/testimonial/01.jpg",
        stars: 5,
        title: "Testimonials",
        heading: "What’s Clients Say",
        content: "Nullam dignissim, ante scelerisque the is euismod fermentum odio sem semper the is erat, a feugiat leo urna eget eros. Duis Aenean a imperdiet risus. Aliquam pellentesque nisi dui eget dapibus enim ornare eu. Morbi nunc metus, maximus eu mauris.",
        author: "Kathryn Murphy",
        position: "Web Designer"
    },
    {
        id:4,
        image: "/img/testimonial/01.jpg",
        stars: 5,
        title: "Testimonials",
        heading: "What’s Clients Say",
        content: "Nullam dignissim, ante scelerisque the is euismod fermentum odio sem semper the is erat, a feugiat leo urna eget eros. Duis Aenean a imperdiet risus. Aliquam pellentesque nisi dui eget dapibus enim ornare eu. Morbi nunc metus, maximus eu mauris.",
        author: "Kathryn Murphy",
        position: "Web Designer"
    },
    {
        id:5,
        image: "/img/testimonial/01.jpg",
        stars: 5,
        title: "Testimonials",
        heading: "What’s Clients Say",
        content: "Nullam dignissim, ante scelerisque the is euismod fermentum odio sem semper the is erat, a feugiat leo urna eget eros. Duis Aenean a imperdiet risus. Aliquam pellentesque nisi dui eget dapibus enim ornare eu. Morbi nunc metus, maximus eu mauris.",
        author: "Kathryn Murphy",
        position: "Web Designer"
    },
    
];